micro-notification-service-2

Things to do directly in AWS Console (for now)

- Create SNS Platform application for every app and create in Apps table the appropriate record with Sns platform arns
